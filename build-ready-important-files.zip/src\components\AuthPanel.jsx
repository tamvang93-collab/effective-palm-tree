import { useMemo, useState } from "react";

function mapReason(reason) {
  const dict = {
    USERNAME_TOO_SHORT: "Ten dang nhap toi thieu 3 ky tu.",
    PASSWORD_TOO_SHORT: "Mat khau toi thieu 6 ky tu.",
    USER_EXISTS: "Ten dang nhap da ton tai.",
    USER_NOT_FOUND: "Khong tim thay tai khoan.",
    INVALID_PASSWORD: "Mat khau khong dung.",
    ACCOUNT_LOCKED: "Tai khoan dang bi khoa tam thoi do nhap sai nhieu lan.",
    RATE_LIMITED: "Ban thao tac qua nhanh. Vui long thu lai sau.",
    NETWORK_ERROR: "Khong ket noi duoc den may chu API."
  };
  return dict[reason] ?? "Da xay ra loi, vui long thu lai.";
}

export default function AuthPanel({ onLogin, onRegister }) {
  const [mode, setMode] = useState("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const title = useMemo(() => (mode === "login" ? "DANG NHAP" : "DANG KY TAI KHOAN"), [mode]);

  const submit = async () => {
    setLoading(true);
    setError("");
    const action = mode === "login" ? onLogin : onRegister;
    const result = await action?.({ username, password });
    if (!result?.ok) {
      setError(mapReason(result?.reason));
    }
    setLoading(false);
  };

  return (
    <div className="mx-auto mt-14 w-full max-w-md rounded-3xl border border-white/10 bg-slate-950/80 p-6 shadow-2xl">
      <h2 className="text-center text-xl font-black tracking-[0.2em] text-cyan-200">{title}</h2>
      <p className="mt-2 text-center text-xs font-semibold tracking-[0.12em] text-white/60">
        HE THONG XAC THUC + LUU THONG TIN NGUOI DUNG
      </p>

      <div className="mt-5 space-y-3">
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Ten dang nhap"
          className="w-full rounded-xl border border-white/15 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-cyan-200/40"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Mat khau"
          className="w-full rounded-xl border border-white/15 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-cyan-200/40"
        />
      </div>

      {error ? <p className="mt-3 text-xs font-semibold text-rose-300">{error}</p> : null}

      <button
        type="button"
        onClick={submit}
        disabled={loading}
        className="mt-4 w-full rounded-xl bg-cyan-300 px-4 py-2 text-sm font-black tracking-[0.16em] text-slate-950 transition hover:brightness-105 disabled:opacity-60"
      >
        {loading ? "DANG XU LY..." : mode === "login" ? "DANG NHAP" : "TAO TAI KHOAN"}
      </button>

      <button
        type="button"
        onClick={() => {
          setMode((prev) => (prev === "login" ? "register" : "login"));
          setError("");
        }}
        className="mt-3 w-full rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-bold tracking-[0.14em] text-white/80 transition hover:bg-white/10"
      >
        {mode === "login" ? "CHUA CO TAI KHOAN? DANG KY" : "DA CO TAI KHOAN? DANG NHAP"}
      </button>
    </div>
  );
}
