import { motion } from "framer-motion";

export default function ProviderCard({ provider, onOpen }) {
  return (
    <motion.button
      type="button"
      whileHover={{ scale: 1.02, y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onOpen(provider)}
      className="group relative overflow-hidden rounded-3xl border border-cyan-300/35 bg-slate-900/75 p-3 text-left shadow-glow transition-all duration-300 hover:border-cyan-200/60"
    >
      {provider.isActive ? (
        <span className="absolute right-4 top-4 z-20 rounded-full bg-emerald-500 px-3 py-1 text-[10px] font-extrabold tracking-[0.2em] text-slate-950 animate-pulseSoft">
          HOAT DONG
        </span>
      ) : null}

      <div className="relative h-44 overflow-hidden rounded-2xl">
        <img
          src={provider.image}
          alt={provider.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/20 to-transparent" />
      </div>

      <div className="px-2 pb-2 pt-4">
        <p className="mb-3 text-lg font-bold tracking-wide text-white">{provider.name}</p>
        <div className="inline-flex min-w-32 items-center justify-center rounded-full bg-cyan-400 px-6 py-2 text-sm font-extrabold text-slate-950 shadow-md shadow-cyan-400/40">
          {provider.shortName}
        </div>
        <p className="mt-3 text-xs font-semibold tracking-[0.28em] text-slate-300">{provider.lobbyLabel}</p>
      </div>
    </motion.button>
  );
}
