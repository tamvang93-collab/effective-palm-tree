import bigtoolGameListJsRaw from "../../bigtool_game-list.js?raw";
import { buildGameImageUrl } from "../config/assets";

const providerPlaceholder = (text, colorA, colorB) =>
  `https://placehold.co/640x360/${colorA}/${colorB}?text=${encodeURIComponent(text)}`;

export const providers = [
  {
    id: "pg",
    name: "PG SOFT",
    shortName: "PG",
    lobbyLabel: "SANH PG",
    image: "/sanh-game-images/sanh_game_images/PG.png",
    isActive: true
  },
  {
    id: "jili",
    name: "JILI",
    shortName: "JILI",
    lobbyLabel: "SANH JILI",
    image: "/sanh-game-images/sanh_game_images/JL.png",
    isActive: true
  },
  {
    id: "fc",
    name: "FC FA CHAI",
    shortName: "FC",
    lobbyLabel: "SANH FC",
    image: "/sanh-game-images/sanh_game_images/FC.png",
    isActive: true
  },
  {
    id: "jdb",
    name: "JDB",
    shortName: "JDB",
    lobbyLabel: "SANH JDB",
    image: "/sanh-game-images/sanh_game_images/JDB.png",
    isActive: true
  },
  {
    id: "pragmatic",
    name: "PRAGMATIC PLAY",
    shortName: "PLAY",
    lobbyLabel: "SANH PLAY",
    image: "/sanh-game-images/sanh_game_images/PP.png",
    isActive: true
  },
  {
    id: "topplayer",
    name: "TOP PLAYER",
    shortName: "TP",
    lobbyLabel: "SANH TP",
    image: "/sanh-game-images/sanh_game_images/TP.png",
    isActive: true
  },
  {
    id: "168game",
    name: "168GAME",
    shortName: "168G",
    lobbyLabel: "SANH 168G",
    image: "/sanh-game-images/sanh_game_images/168G.png",
    isActive: true
  },
  {
    id: "cq9",
    name: "CQ9",
    shortName: "CQ9",
    lobbyLabel: "SANH CQ9",
    image: "/sanh-game-images/sanh_game_images/CQ9.png",
    isActive: true
  },
  {
    id: "turbo",
    name: "TURBO GAMES",
    shortName: "TUBOR",
    lobbyLabel: "SANH TUBOR",
    image: "/sanh-game-images/sanh_game_images/TB.png",
    isActive: true
  },
  {
    id: "microgaming",
    name: "MICROGAMING",
    shortName: "MG",
    lobbyLabel: "SANH MG",
    image: "/sanh-game-images/sanh_game_images/MG.png",
    isActive: true
  }
];

function gameNameToSlug(gameName) {
  // Keep identical slug rules to bigtool so the image filenames match.
  const vietnameseMap = {
    à: "a",
    á: "a",
    ạ: "a",
    ả: "a",
    ã: "a",
    â: "a",
    ầ: "a",
    ấ: "a",
    ậ: "a",
    ẩ: "a",
    ẫ: "a",
    ă: "a",
    ằ: "a",
    ắ: "a",
    ặ: "a",
    ẳ: "a",
    ẵ: "a",
    è: "e",
    é: "e",
    ẹ: "e",
    ẻ: "e",
    ẽ: "e",
    ê: "e",
    ề: "e",
    ế: "e",
    ệ: "e",
    ể: "e",
    ễ: "e",
    ì: "i",
    í: "i",
    ị: "i",
    ỉ: "i",
    ĩ: "i",
    ı: "i",
    ò: "o",
    ó: "o",
    ọ: "o",
    ỏ: "o",
    õ: "o",
    ô: "o",
    ồ: "o",
    ố: "o",
    ộ: "o",
    ổ: "o",
    ỗ: "o",
    ơ: "o",
    ờ: "o",
    ớ: "o",
    ợ: "o",
    ở: "o",
    ỡ: "o",
    ù: "u",
    ú: "u",
    ụ: "u",
    ủ: "u",
    ũ: "u",
    ư: "u",
    ừ: "u",
    ứ: "u",
    ự: "u",
    ử: "u",
    ữ: "u",
    ỳ: "y",
    ý: "y",
    ỵ: "y",
    ỷ: "y",
    ỹ: "y",
    đ: "d",
    À: "A",
    Á: "A",
    Ạ: "A",
    Ả: "A",
    Ã: "A",
    Â: "A",
    Ầ: "A",
    Ấ: "A",
    Ậ: "A",
    Ẩ: "A",
    Ẫ: "A",
    Ă: "A",
    Ằ: "A",
    Ắ: "A",
    Ặ: "A",
    Ẳ: "A",
    Ẵ: "A",
    È: "E",
    É: "E",
    Ẹ: "E",
    Ẻ: "E",
    Ẽ: "E",
    Ê: "E",
    Ề: "E",
    Ế: "E",
    Ệ: "E",
    Ể: "E",
    Ễ: "E",
    Ì: "I",
    Í: "I",
    Ị: "I",
    Ỉ: "I",
    Ĩ: "I",
    İ: "I",
    Ò: "O",
    Ó: "O",
    Ọ: "O",
    Ỏ: "O",
    Õ: "O",
    Ô: "O",
    Ồ: "O",
    Ố: "O",
    Ộ: "O",
    Ổ: "O",
    Ỗ: "O",
    Ơ: "O",
    Ờ: "O",
    Ớ: "O",
    Ợ: "O",
    Ở: "O",
    Ỡ: "O",
    Ù: "U",
    Ú: "U",
    Ụ: "U",
    Ủ: "U",
    Ũ: "U",
    Ư: "U",
    Ừ: "U",
    Ứ: "U",
    Ự: "U",
    Ử: "U",
    Ữ: "U",
    Ỳ: "Y",
    Ý: "Y",
    Ỵ: "Y",
    Ỷ: "Y",
    Ỹ: "Y",
    Đ: "D"
  };

  let slug = gameName;

  for (const key in vietnameseMap) {
    slug = slug.replace(new RegExp(key, "g"), vietnameseMap[key]);
  }

  slug = slug
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

  return slug;
}

function extractProviderTitlesFromBigtool(providerKey) {
  const key = providerKey.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`'${key}'\\s*:\\s*\\[([\\s\\S]*?)\\]\\s*(,|\\n\\s*})`);
  const m = bigtoolGameListJsRaw.match(re);
  if (!m) return [];

  const block = m[1];
  const titles = [];
  const titleRe = /'([^']+)'/g;
  let match;
  while ((match = titleRe.exec(block))) {
    titles.push(match[1]);
  }

  return titles;
}

const cdnGameImage = (providerKey, slug) => buildGameImageUrl(providerKey, slug, "webp");

function buildGamesForProvider(providerKey) {
  const titles = extractProviderTitlesFromBigtool(providerKey);
  return titles.map((title, i) => {
    const isHot = i % 7 === 0;
    const isNew = i % 5 === 0 && !isHot;
    const slug = gameNameToSlug(title);

    return {
      id: `${providerKey}-${slug}-${i}`,
      title,
      image: cdnGameImage(providerKey, slug),
      isHot,
      isNew,
      multiplier: isHot ? "5,000x" : null
    };
  });
}

export const gamesByProvider = {
  pg: buildGamesForProvider("pg"),
  jili: buildGamesForProvider("jili"),
  fc: buildGamesForProvider("fc"),
  jdb: buildGamesForProvider("jdb"),
  pragmatic: buildGamesForProvider("pragmatic"),
  topplayer: buildGamesForProvider("topplayer"),
  "168game": buildGamesForProvider("168game"),
  cq9: buildGamesForProvider("cq9"),
  turbo: buildGamesForProvider("turbo"),
  microgaming: buildGamesForProvider("microgaming")
};
