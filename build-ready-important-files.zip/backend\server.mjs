import "dotenv/config";
import crypto from "node:crypto";
import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import cookieParser from "cookie-parser";
import {
  authMiddleware,
  generateTokenFamily,
  hashToken,
  signRefreshToken,
  signUserToken,
  verifyRefreshToken
} from "./auth.mjs";
import { createDbConnection, runMigrations } from "./db.mjs";

function mapUser(row) {
  return {
    id: row.id,
    username: row.username,
    vip: row.vip,
    balance: row.balance,
    xu: row.balance,
    coins: row.balance,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

const LOGIN_WINDOW_MS = Number(process.env.AUTH_RATE_LIMIT_WINDOW_MS || 60_000);
const LOGIN_LIMIT = Number(process.env.AUTH_RATE_LIMIT_MAX || 20);
const LOCK_MINUTES = Number(process.env.AUTH_LOCK_MINUTES || 15);
const LOCK_THRESHOLD = Number(process.env.AUTH_LOCK_THRESHOLD || 5);
const REFRESH_COOKIE_NAME = "refresh_token";

function createRateLimiter() {
  const store = new Map();
  return (key) => {
    const now = Date.now();
    const current = store.get(key) ?? { count: 0, start: now };
    if (now - current.start > LOGIN_WINDOW_MS) {
      current.count = 0;
      current.start = now;
    }
    current.count += 1;
    store.set(key, current);
    return current.count <= LOGIN_LIMIT;
  };
}

function getClientFingerprint(req) {
  const ua = req.headers["user-agent"] || "unknown";
  return `${ua}`.slice(0, 300);
}

function getClientIp(req) {
  return req.headers["x-forwarded-for"]?.toString().split(",")[0]?.trim() || req.ip || "unknown";
}

function writeAuditLog(db, { userId = null, username = null, action, status, req, detail = null }) {
  db.prepare(
    `INSERT INTO auth_logs (user_id, username, action, status, ip, user_agent, detail, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    userId,
    username,
    action,
    status,
    getClientIp(req),
    (req.headers["user-agent"] || "").toString().slice(0, 400),
    detail,
    new Date().toISOString()
  );
}

function issueSessionTokens(db, user, req, tokenFamily = generateTokenFamily()) {
  const accessToken = signUserToken(user);
  const refreshToken = signRefreshToken({
    sub: user.id,
    username: user.username,
    family: tokenFamily,
    jti: crypto.randomUUID()
  });
  const refreshHash = hashToken(refreshToken);
  const now = new Date().toISOString();
  const expiresAt = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString();
  db.prepare(
    `INSERT INTO auth_sessions
    (user_id, token_family, refresh_token_hash, expires_at, revoked_at, client_fingerprint, created_at, updated_at)
    VALUES (?, ?, ?, ?, NULL, ?, ?, ?)`
  ).run(user.id, tokenFamily, refreshHash, expiresAt, getClientFingerprint(req), now, now);

  return { accessToken, refreshToken };
}

function clearRefreshCookie(res) {
  res.clearCookie(REFRESH_COOKIE_NAME, {
    httpOnly: true,
    sameSite: "lax",
    secure: false
  });
}

export function createApp(db) {
  const allowAuthAttempt = createRateLimiter();
  const app = express();
  app.use(cors({ origin: true, credentials: true }));
  app.use(cookieParser());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true });
  });

  app.post("/api/auth/register", async (req, res) => {
    const username = String(req.body?.username ?? "").trim();
    const password = String(req.body?.password ?? "");

    if (username.length < 3) {
      return res.status(400).json({ ok: false, reason: "USERNAME_TOO_SHORT" });
    }
    if (password.length < 6) {
      return res.status(400).json({ ok: false, reason: "PASSWORD_TOO_SHORT" });
    }

    const existed = db.prepare("SELECT id FROM users WHERE lower(username) = lower(?)").get(username);
    if (existed) {
      return res.status(409).json({ ok: false, reason: "USER_EXISTS" });
    }

    const now = new Date().toISOString();
    const passwordHash = await bcrypt.hash(password, 12);
    const insert = db
      .prepare(
        "INSERT INTO users (username, password_hash, vip, balance, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)"
      )
      .run(username, passwordHash, 0, 1200, now, now);

    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(insert.lastInsertRowid);
    const tokens = issueSessionTokens(db, user, req);
    writeAuditLog(db, { userId: user.id, username, action: "register", status: "success", req });
    res.cookie(REFRESH_COOKIE_NAME, tokens.refreshToken, {
      httpOnly: true,
      sameSite: "lax",
      secure: false
    });
    return res.json({ ok: true, token: tokens.accessToken, user: mapUser(user) });
  });

  app.post("/api/auth/login", async (req, res) => {
    const username = String(req.body?.username ?? "").trim();
    const password = String(req.body?.password ?? "");
    const rateKey = `${getClientIp(req)}:${username.toLowerCase()}`;
    if (!allowAuthAttempt(rateKey)) {
      writeAuditLog(db, { username, action: "login", status: "blocked_rate_limit", req });
      return res.status(429).json({ ok: false, reason: "RATE_LIMITED" });
    }

    const user = db.prepare("SELECT * FROM users WHERE lower(username) = lower(?)").get(username);

    if (!user) {
      writeAuditLog(db, { username, action: "login", status: "user_not_found", req });
      return res.status(404).json({ ok: false, reason: "USER_NOT_FOUND" });
    }

    if (user.lock_until && new Date(user.lock_until).getTime() > Date.now()) {
      writeAuditLog(db, { userId: user.id, username, action: "login", status: "blocked_lockout", req });
      return res.status(423).json({ ok: false, reason: "ACCOUNT_LOCKED" });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      const attempts = (user.failed_attempts ?? 0) + 1;
      let lockUntil = null;
      if (attempts >= LOCK_THRESHOLD) {
        lockUntil = new Date(Date.now() + LOCK_MINUTES * 60_000).toISOString();
      }
      db.prepare("UPDATE users SET failed_attempts = ?, lock_until = ?, updated_at = ? WHERE id = ?")
        .run(attempts, lockUntil, new Date().toISOString(), user.id);
      writeAuditLog(db, { userId: user.id, username, action: "login", status: "invalid_password", req });
      return res.status(401).json({ ok: false, reason: lockUntil ? "ACCOUNT_LOCKED" : "INVALID_PASSWORD" });
    }

    db.prepare("UPDATE users SET failed_attempts = 0, lock_until = NULL, updated_at = ? WHERE id = ?")
      .run(new Date().toISOString(), user.id);
    db.prepare("UPDATE auth_sessions SET revoked_at = ?, updated_at = ? WHERE user_id = ? AND revoked_at IS NULL")
      .run(new Date().toISOString(), new Date().toISOString(), user.id);

    const freshUser = db.prepare("SELECT * FROM users WHERE id = ?").get(user.id);
    const tokens = issueSessionTokens(db, freshUser, req);
    writeAuditLog(db, { userId: user.id, username, action: "login", status: "success", req });
    res.cookie(REFRESH_COOKIE_NAME, tokens.refreshToken, {
      httpOnly: true,
      sameSite: "lax",
      secure: false
    });
    return res.json({ ok: true, token: tokens.accessToken, user: mapUser(freshUser) });
  });

  app.post("/api/auth/refresh", (req, res) => {
    const refreshToken = req.cookies?.[REFRESH_COOKIE_NAME] || req.body?.refreshToken;
    if (!refreshToken) return res.status(401).json({ ok: false, reason: "NO_REFRESH_TOKEN" });

    let payload;
    try {
      payload = verifyRefreshToken(refreshToken);
    } catch {
      writeAuditLog(db, { username: null, action: "refresh", status: "invalid_refresh_token", req });
      return res.status(401).json({ ok: false, reason: "INVALID_REFRESH_TOKEN" });
    }

    const hashed = hashToken(refreshToken);
    const session = db
      .prepare("SELECT * FROM auth_sessions WHERE refresh_token_hash = ? AND revoked_at IS NULL")
      .get(hashed);
    if (!session) {
      writeAuditLog(db, { userId: payload.sub, username: payload.username, action: "refresh", status: "revoked", req });
      return res.status(401).json({ ok: false, reason: "SESSION_REVOKED" });
    }

    if (new Date(session.expires_at).getTime() < Date.now()) {
      db.prepare("UPDATE auth_sessions SET revoked_at = ?, updated_at = ? WHERE id = ?")
        .run(new Date().toISOString(), new Date().toISOString(), session.id);
      writeAuditLog(db, { userId: payload.sub, username: payload.username, action: "refresh", status: "expired", req });
      return res.status(401).json({ ok: false, reason: "REFRESH_EXPIRED" });
    }

    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(payload.sub);
    if (!user) return res.status(404).json({ ok: false, reason: "USER_NOT_FOUND" });

    db.prepare("UPDATE auth_sessions SET revoked_at = ?, updated_at = ? WHERE id = ?")
      .run(new Date().toISOString(), new Date().toISOString(), session.id);

    const tokens = issueSessionTokens(db, user, req, payload.family);
    writeAuditLog(db, { userId: user.id, username: user.username, action: "refresh", status: "success", req });
    res.cookie(REFRESH_COOKIE_NAME, tokens.refreshToken, {
      httpOnly: true,
      sameSite: "lax",
      secure: false
    });
    return res.json({ ok: true, token: tokens.accessToken, user: mapUser(user) });
  });

  app.get("/api/auth/me", authMiddleware, (req, res) => {
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.auth.sub);
    if (!user) return res.status(404).json({ ok: false, reason: "USER_NOT_FOUND" });
    return res.json({ ok: true, user: mapUser(user) });
  });

  app.post("/api/auth/logout", authMiddleware, (_req, res) => {
    const refreshToken = _req.cookies?.[REFRESH_COOKIE_NAME] || _req.body?.refreshToken;
    if (refreshToken) {
      db.prepare("UPDATE auth_sessions SET revoked_at = ?, updated_at = ? WHERE refresh_token_hash = ?")
        .run(new Date().toISOString(), new Date().toISOString(), hashToken(refreshToken));
    }
    writeAuditLog(db, { userId: _req.auth.sub, username: _req.auth.username, action: "logout", status: "success", req: _req });
    clearRefreshCookie(res);
    return res.json({ ok: true });
  });

  app.post("/api/auth/logout-all", authMiddleware, (req, res) => {
    db.prepare("UPDATE auth_sessions SET revoked_at = ?, updated_at = ? WHERE user_id = ? AND revoked_at IS NULL")
      .run(new Date().toISOString(), new Date().toISOString(), req.auth.sub);
    writeAuditLog(db, { userId: req.auth.sub, username: req.auth.username, action: "logout_all", status: "success", req });
    clearRefreshCookie(res);
    return res.json({ ok: true });
  });

  app.post("/api/user/deduct-xu", authMiddleware, (req, res) => {
    const amount = Math.max(1, Number(req.body?.amount ?? 10));
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.auth.sub);
    if (!user) return res.status(404).json({ ok: false, reason: "USER_NOT_FOUND" });
    if (user.balance < amount) return res.status(400).json({ ok: false, reason: "INSUFFICIENT_BALANCE" });

    const nextBalance = user.balance - amount;
    db.prepare("UPDATE users SET balance = ?, updated_at = ? WHERE id = ?")
      .run(nextBalance, new Date().toISOString(), user.id);

    return res.json({ ok: true, newBalance: nextBalance });
  });

  return app;
}

export function startServer() {
  const db = createDbConnection();
  runMigrations(db);
  const app = createApp(db);
  const port = Number(process.env.API_PORT || 4000);

  app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`API server running on http://localhost:${port}`);
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
