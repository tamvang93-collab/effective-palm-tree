import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";

function Badge({ children, tone }) {
  const tones = {
    hot: "from-orange-500 to-red-600",
    new: "from-lime-400 to-emerald-600"
  };

  return (
    <span
      className={`rounded-full bg-gradient-to-r ${tones[tone]} px-2.5 py-1 text-[10px] font-black tracking-[0.14em] text-white shadow-lg`}
    >
      {children}
    </span>
  );
}

function GameImage({ game }) {
  const imageFallback = useMemo(() => {
    if (!game?.image) return null;
    return game.image.replace(/\.(webp|png|jpe?g|jpeg)$/i, "");
  }, [game?.image]);

  const formats = ["webp", "png", "jpg", "jpeg"];
  const [formatIndex, setFormatIndex] = useState(0);

  useEffect(() => {
    setFormatIndex(0);
  }, [game?.id]);

  const resolvedSrc =
    imageFallback && formats[formatIndex]
      ? `${imageFallback}.${formats[formatIndex]}`
      : game?.image;

  return (
    <img
      src={resolvedSrc}
      alt={game?.title ?? "Game"}
      className="h-[320px] w-full rounded-2xl object-cover sm:h-[360px]"
      onError={() => {
        setFormatIndex((idx) => {
          const next = idx + 1;
          return next < formats.length ? next : idx;
        });
      }}
    />
  );
}

export default function GameDetailModal({ open, game, onClose, onPlay, onLowBalance }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKeyDown = (e) => {
      if (e.key === "Escape") onClose?.();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          key="overlay"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 py-6 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) onClose?.();
          }}
        >
          <motion.div
            key="modal"
            className="w-full max-w-3xl overflow-hidden rounded-3xl border border-white/10 bg-slate-950/85 shadow-2xl"
            initial={{ opacity: 0, y: 18, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 26 }}
          >
            <div className="grid gap-0 sm:grid-cols-[1.2fr_1fr]">
              <div className="relative p-4">
                <div className="absolute left-6 top-6 z-10 flex flex-col gap-2">
                  {game?.isHot ? <Badge tone="hot">{game?.multiplier ?? "5,000x"}</Badge> : null}
                  {game?.isNew ? <Badge tone="new">MỚI</Badge> : null}
                </div>
                <GameImage game={game} />
              </div>

              <div className="flex flex-col gap-4 p-5 sm:p-6">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-lg font-black tracking-wide text-white sm:text-xl">{game?.title ?? ""}</h3>
                    <p className="mt-1 text-xs font-semibold tracking-[0.22em] text-white/60">CHI TIET GAME</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onClose?.()}
                    className="rounded-full border border-white/15 bg-white/5 px-3 py-2 text-xs font-black tracking-[0.16em] text-white/80 transition hover:bg-white/10 hover:text-white"
                    aria-label="Close modal"
                  >
                    DONG
                  </button>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-xs font-bold tracking-[0.18em] text-white/70">HE SO</p>
                    <p className="text-sm font-black tracking-wide text-brand-gold">{game?.multiplier ?? "-"}</p>
                  </div>
                </div>

                <div className="mt-auto grid grid-cols-1 gap-3">
                  <button
                    type="button"
                    onClick={() => onPlay?.(game)}
                    className="rounded-2xl bg-brand-gold px-4 py-3 text-sm font-black tracking-[0.18em] text-slate-950 transition hover:brightness-110"
                  >
                    VAO CHOI
                  </button>
                  <button
                    type="button"
                    onClick={() => onLowBalance?.()}
                    className="rounded-2xl border border-amber-200/20 bg-amber-200/10 px-4 py-3 text-xs font-black tracking-[0.18em] text-amber-100 transition hover:bg-amber-200/15"
                  >
                    TEST CANH BAO THIEU XU
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

