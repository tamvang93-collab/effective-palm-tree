import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import GameCard from "./components/GameCard";
import GameDetailModal from "./components/GameDetailModal";
import LowBalancePopup from "./components/LowBalancePopup";
import ProviderCard from "./components/ProviderCard";
import { gamesByProvider, providers } from "./data/mockData";

const PROVIDER_QUERY_KEY = "provider";

function getProviderFromLocation() {
  if (typeof window === "undefined") return null;
  const params = new URLSearchParams(window.location.search);
  const provider = params.get(PROVIDER_QUERY_KEY);
  return provider && provider.trim().length > 0 ? provider.trim() : null;
}

function setProviderInLocation(providerId) {
  if (typeof window === "undefined") return;
  const url = new URL(window.location.href);

  if (!providerId) {
    url.searchParams.delete(PROVIDER_QUERY_KEY);
  } else {
    url.searchParams.set(PROVIDER_QUERY_KEY, providerId);
  }

  window.history.pushState({ providerId: providerId ?? null }, "", url);
}

export default function App() {
  const [selectedProviderId, setSelectedProviderId] = useState(() => getProviderFromLocation());
  const [searchText, setSearchText] = useState("");
  const [selectedGame, setSelectedGame] = useState(null);
  const [lowBalanceOpen, setLowBalanceOpen] = useState(false);
  const selectedProvider = useMemo(
    () => providers.find((provider) => provider.id === selectedProviderId) ?? null,
    [selectedProviderId]
  );

  const games = selectedProviderId ? gamesByProvider[selectedProviderId] ?? [] : [];

  useEffect(() => {
    setSearchText("");
    setSelectedGame(null);
  }, [selectedProviderId]);

  const filteredGames = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    if (!q) return games;
    return games.filter((g) => (g?.title ?? "").toLowerCase().includes(q));
  }, [games, searchText]);

  useEffect(() => {
    if (typeof window === "undefined") return undefined;

    const onPopState = () => {
      setSelectedProviderId(getProviderFromLocation());
    };

    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  useEffect(() => {
    // Keep URL in sync when provider changes internally.
    // Avoid infinite loops by only pushing when the query differs.
    if (typeof window === "undefined") return;
    const current = getProviderFromLocation();
    if ((current ?? null) !== (selectedProviderId ?? null)) {
      setProviderInLocation(selectedProviderId);
    }
  }, [selectedProviderId]);

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,#0f2440_0%,#070b16_45%,#03050a_100%)] px-4 py-8 text-white sm:px-6 lg:px-10">
      <div className="mx-auto max-w-[1800px]">
        <header className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black tracking-wider text-brand-gold sm:text-3xl">META NO HU</h1>
            <p className="mt-1 text-sm font-medium tracking-[0.2em] text-slate-300">HE THONG GAME</p>
          </div>

          {selectedProvider ? (
            <button
              type="button"
              onClick={() => setSelectedProviderId(null)}
              className="rounded-full border border-white/20 bg-white/5 px-4 py-2 text-xs font-bold tracking-[0.16em] text-white transition hover:bg-white/10"
            >
              QUAY VE SANH
            </button>
          ) : null}
        </header>

        <AnimatePresence mode="wait">
          {!selectedProvider ? (
            <motion.section
              key="lobby"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
            >
              <h2 className="mb-5 text-xl font-extrabold tracking-[0.18em] text-cyan-300">SANH GAME</h2>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
                {providers.map((provider) => (
                  <ProviderCard
                    key={provider.id}
                    provider={provider}
                    onOpen={() => setSelectedProviderId(provider.id)}
                  />
                ))}
              </div>
            </motion.section>
          ) : (
            <motion.section
              key="games"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
            >
              <h2 className="mb-2 text-xl font-extrabold tracking-[0.18em] text-cyan-300">{selectedProvider.name}</h2>
              <p className="mb-6 text-xs font-semibold tracking-[0.22em] text-slate-300">{selectedProvider.lobbyLabel}</p>

              <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex flex-1 items-center gap-3">
                  <div className="flex-1 rounded-full border border-white/15 bg-white/5 px-4 py-2">
                    <input
                      value={searchText}
                      onChange={(e) => setSearchText(e.target.value)}
                      placeholder="TÌM GAME..."
                      className="w-full bg-transparent text-xs font-bold tracking-[0.16em] text-white placeholder:text-white/35 focus:outline-none"
                      aria-label="Search games"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (filteredGames.length === 0) return;
                      const pick = filteredGames[Math.floor(Math.random() * filteredGames.length)];
                      const el = document.getElementById(`game-${pick.id}`);
                      el?.scrollIntoView({ behavior: "smooth", block: "center" });
                    }}
                    className="rounded-full border border-emerald-200/20 bg-emerald-300/10 px-4 py-2 text-xs font-black tracking-[0.16em] text-emerald-100 transition hover:bg-emerald-300/15"
                  >
                    RANDOM
                  </button>
                </div>

                <div className="text-xs font-bold tracking-[0.16em] text-white/70">
                  {filteredGames.length}/{games.length}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 2xl:grid-cols-8">
                {filteredGames.map((game) => (
                  <GameCard key={game.id} game={game} id={`game-${game.id}`} onOpen={() => setSelectedGame(game)} />
                ))}
              </div>

              {filteredGames.length === 0 ? (
                <div className="mt-8 rounded-2xl border border-amber-300/30 bg-amber-100/5 p-6 text-center">
                  <p className="text-sm font-bold tracking-wide text-amber-200">
                    {games.length === 0 ? "CHUA CO DU LIEU GAME CHO SANH NAY" : "KHONG TIM THAY GAME PHU HOP"}
                  </p>
                </div>
              ) : null}
            </motion.section>
          )}
        </AnimatePresence>
      </div>

      <GameDetailModal
        open={Boolean(selectedGame)}
        game={selectedGame}
        onClose={() => setSelectedGame(null)}
        onPlay={() => {
          // Placeholder hook for later business flow.
          setSelectedGame(null);
        }}
        onLowBalance={() => {
          setLowBalanceOpen(true);
        }}
      />

      <LowBalancePopup
        open={lowBalanceOpen}
        onClose={() => setLowBalanceOpen(false)}
        onDeposit={() => {
          // Placeholder: wire to your real deposit flow/route.
          setLowBalanceOpen(false);
        }}
      />
    </main>
  );
}
