# Provider Lobby UI

Giao dien React + Tailwind + framer-motion mo phong he thong sanh game va danh sach game.

## Chay du an

1. Cai Node.js (khuyen nghi Node 20+).
2. Cai package:
   - `npm install`
3. Chay local:
   - `npm run dev`
4. Build/preview:
   - `npm run build`
   - `npm run preview`

## Routing (share link)

- Lobby: `/`
- Mo thang sanh: `/?provider=pg` (ho tro back/forward + refresh giu trang thai)

## CDN assets (anh game)

- Set bien moi truong `VITE_ASSETS_BASE_URL` (VD: `https://cdn.example.com`)
- Anh game se duoc build thanh: `${VITE_ASSETS_BASE_URL}/assets/img/games/<provider>/<slug>.webp`

## Cau truc du lieu

`src/data/mockData.js`

- `Provider Object`:
  - `id`
  - `name`
  - `shortName`
  - `lobbyLabel`
  - `image` (ho tro URL hoac Base64 data URI)
  - `isActive`
- `Game Object`:
  - `id`
  - `title`
  - `image`
  - `multiplier`
  - `isHot`
  - `isNew`

## Luu y

- HTML/bo cuc co the thay doi linh hoat theo tung giai doan du an.
- Ban chi can sua du lieu trong `mockData.js` de them/xoa provider va game.

## Asset manifest / download (de upload CDN)

- Tao manifest:
  - `npm run assets:manifest`
- Tai anh tu bigtool (de ban upload len CDN sau):
  - `npm run assets:download`
  - Gioi han so file: `set DOWNLOAD_LIMIT=200 && npm run assets:download`
  - Chon dinh dang: `set DOWNLOAD_EXT=webp && npm run assets:download`
